jQuery(document).ready(function(){
	jQuery("aside ul li a").on("click",function(e) {
		"use strict"
		e.preventDefault();
		var target = jQuery(this).attr('href').slice(1);

		jQuery('html, body').animate({
            scrollTop: (jQuery("#"+target).offset().top) - 150
        }, 500);
	})

	// Enable the magnificPopup
    jQuery('.img-popup').magnificPopup({
        type: 'image',
        removalDelay: 600,
        mainClass: 'mfp-fade',
    });
});