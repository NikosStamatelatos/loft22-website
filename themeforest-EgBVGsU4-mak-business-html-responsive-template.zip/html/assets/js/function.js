(function ($) {
    'use strict';

    //  lightcase js
    $('a[data-rel^=lightcase]').lightcase();

    //  carousel js
    $('#carousel-testimonial').carousel({
        interval: 200000
    });

    // init Isotope
    var $grid = $('.grid').isotope({
        itemSelector: '.element-item',
        layoutMode: 'fitRows',
        getSortData: {
            name: '.name',
            symbol: '.symbol',
            number: '.number parseInt',
            category: '[data-category]',
            weight: function (itemElem) {
                var weight = $(itemElem).find('.weight').text();
                return parseFloat(weight.replace(/[\(\)]/g, ''));
            }
        }
    });

    // filter functions
    var filterFns = {
        // show if number is greater than 50
        numberGreaterThan50: function () {
            var number = $(this).find('.number').text();
            return parseInt(number, 10) > 50;
        },
        // show if name ends with -ium
        ium: function () {
            var name = $(this).find('.name').text();
            return name.match(/ium$/);
        }
    };

    $('a.page-scroll').on('click', function(event) {
        var $anchor = $(this);
        $('html, body').stop().animate({
            scrollTop: $($anchor.attr('href')).offset().top
        }, 1500, 'easeInOutExpo');
        event.preventDefault();
    });

    // bind filter button click
    var $grid = $('.grid').isotope({
        itemSelector: '.element-item',
        stagger: 50,
        layoutMode: 'masonry'
        //                , getSortData: {
        //                    
        //                    name: '.name'
        //                    , symbol: '.symbol'
        //                    , number: '.number parseInt'
        //                    , category: '[data-category]'
        //                    , weight: function (itemElem) {
        //                        var weight = $(itemElem).find('.weight').text();
        //                        return parseFloat(weight.replace(/[\(\)]/g, ''));
        //                    }
        //                }
    });

    $('#filters').on('click', 'li', function () {
        var filterValue = $(this).attr('data-filter');
        // use filterFn if matches value
        filterValue = filterFns[filterValue] || filterValue;
        $grid.isotope({
            filter: filterValue
        });
    });

    // change is-checked class on buttons
    $('.button-group').each(function (i, buttonGroup) {
        var $buttonGroup = $(buttonGroup);
        $buttonGroup.on('click', 'li', function () {
            $buttonGroup.find('.is-checked').removeClass('is-checked');
            $(this).addClass('is-checked');
        });
    });

    // Banner Swiper Slider
    var swiper = new Swiper('.banner-container', {
        slidesPerView: 1,
        autoplay: true,
        loop: true,
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.custom-button-next',
            prevEl: '.custom-button-prev',
        },
    });

    //// testimonial Swiper Slider
    var swiper = new Swiper('.testimonial-container', {
        slidesPerView: 1,
        spaceBetween: 30,
        loop: true,
        autoplay: true,
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.test-button-next',
            prevEl: '.test-button-prev',
        },
    });

    //  banner swiper js    
    var swiper = new Swiper('.swiper-container', {
        slidesPerView: 1,
        spaceBetween: 30,
        loop: true,
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
    });

    //menu top fixed
    var fixed_top = $(".main-menu");
    $(window).on('scroll', function () {
        if ($(this).scrollTop() > 80) {
            fixed_top.addClass("menu-fixed animated fadeInDown");
        } else {
            fixed_top.removeClass("menu-fixed animated fadeInDown");
        }

    });

    $(window).on('scroll', function () {
        if ($(window).scrollTop() > 200) {
            $('.primary-menu').addClass('menu-fixed fadeInDown animated');
            $("body").css({
                "padding-top": "90px"
            });
        } else {
            $('.primary-menu').removeClass('menu-fixed fadeInDown animated');
            $("body").css({
                "padding-top": "0px"
            });
        }
    });

    // mobile menu
    jQuery(".menu-toggle").on('click', function (event) {
        jQuery('body').addClass("open-mobile-menu");
    });

    jQuery(".mobile-menu-close").on('click', function (event) {
        jQuery('body').removeClass("open-mobile-menu");
    });

    $('.mobile-menu>li>a,.mobile-menu ul.mobile-submenu>li>a').on('click', function (e) {
        var element = $(this).parent('li');
        if (element.hasClass('open')) {
            element.removeClass('open');
            element.find('li').removeClass('open');
            element.find('ul').slideUp(1500, "swing");
        } else {
            element.addClass('open');
            element.children('ul').slideDown(1500, "swing");
            element.siblings('li').children('ul').slideUp(1500, "swing");
            element.siblings('li').removeClass('open');
            element.siblings('li').find('li').removeClass('open');
            element.siblings('li').find('ul').slideUp(1500, "swing");
        }
    });

		
    // counter up
    $('.counter').counterUp({
        delay: 10,
        time: 2000
    });

    //  search js
    jQuery(".search-icon").on('click', function (event) {
        jQuery('body').addClass("open-search");
    });

    jQuery(".search-close").on('click', function (event) {
        jQuery('body').removeClass("open-search");
    });

    // Add smooth scrolling on all links inside the navbar

    jQuery('body').scrollspy({
        target: ".primary-menu",
        offset: 50
    });

    jQuery(".navbar-menu a").on('click', function (event) {

        // Make sure this.hash has a value before overriding default behavior
        if (this.hash !== "") {

            // Prevent default anchor click behavior
            event.preventDefault();

            // Store hash
            var hash = this.hash;

            // Using jQuery's animate() method to add smooth page scroll
            // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
            jQuery('html, body').animate({
                scrollTop: jQuery(hash).offset().top
            }, 800, function () {

                // Add hash (#) to URL when done scrolling (default click behavior)
                window.location.hash = hash;
            });

        } // End if

    });

    // Add smooth scrolling on all links inside the navbar
    //   arrow-top
    $(".arrow_top").on('click', function () {
        $("html, body").animate({
            scrollTop: 0
        }, 3000);
    });

    $(window).on('scroll', function () {
        var x = $(window).scrollTop();
        if (x > 100) {
            $(".arrow_top").removeClass("disable");
        } else {
            $(".arrow_top").addClass("disable");
        }
    });

    //   arrow-top   

    //  preloader
        jQuery(document).ready(function($) { 
          $(window).on("load",function (){
            $("#preloader").fadeOut(500);
          });
		  		// client js  
		$(".owl-client").owlCarousel({
		  items               : 4,
		  autoPlay            : true,
		  itemsDesktop        : [1199, 4],
		  itemsDesktopSmall   : [980, 3],
		  itemsTablet         : [768, 3],
		  itemsMobile         : [479, 2],
		  pagination          : false,
		  navigation          : false,
		  autoHeight          : true,
		});
        });

})(jQuery);
